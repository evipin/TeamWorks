package demo.tcs.com.manageaccount;

import android.content.Context;
import android.support.test.InstrumentationRegistry;
import android.support.test.runner.AndroidJUnit4;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.List;

import demo.tcs.com.manageaccount.model.AccountDetail;
import demo.tcs.com.manageaccount.util.AppUtil;

/**
 * Instrumentation test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
@RunWith(AndroidJUnit4.class)
public class ManageAccountTest {

    @Test
    public void isListEmpty() throws Exception {
        // Context of the app under test.
        Context appContext = InstrumentationRegistry.getTargetContext();

        List<AccountDetail> list=new AppUtil().parseData(appContext).getAccounts();

        if(list.isEmpty())
            throw new AssertionError("list cannot be empty");

    }
}
