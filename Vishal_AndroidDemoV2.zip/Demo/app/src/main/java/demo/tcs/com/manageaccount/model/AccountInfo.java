package demo.tcs.com.manageaccount.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class AccountInfo
{
    private String returnCode;

    @SerializedName("accounts")
    private List<AccountDetail> accounts;

    private String failedAccountTypes;

    public String getReturnCode ()
    {
        return returnCode;
    }


    public List<AccountDetail> getAccounts ()
    {
        return accounts;
    }



    public String getFailedAccountTypes ()
    {
        return failedAccountTypes;
    }


}