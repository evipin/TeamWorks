package demo.tcs.com.manageaccount.util;

import android.content.Context;
import android.util.Log;

import com.google.gson.Gson;

import java.io.IOException;
import java.io.InputStream;

import demo.tcs.com.manageaccount.model.AccountInfo;

/**
 * Created by 917517 on 7/27/2017.
 * This class is for parsing the data
 */

public class AppUtil {
    /**
     * This method is used to parse the data
     * @param context
     * @return Returns the Account Info object that holds all the information
     */
    public AccountInfo parseData(Context context){

        try {
            InputStream is = context.getAssets().open("data.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            String  json = new String(buffer, "UTF-8");
            Gson gson = new Gson();
            return gson.fromJson(json, AccountInfo.class);
        } catch (IOException ex) {
            Log.d("Error while parsing:",ex.getMessage());
            ex.printStackTrace();
        }
        return null;
    }
}
