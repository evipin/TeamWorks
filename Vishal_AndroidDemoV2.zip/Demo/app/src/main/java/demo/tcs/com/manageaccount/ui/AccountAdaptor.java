package demo.tcs.com.manageaccount.ui;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import java.util.List;
import demo.tcs.com.manageaccount.R;
import demo.tcs.com.manageaccount.model.AccountDetail;

/**
 * Created by 917517 on 7/26/2017.
 */

/**
 * This is Adaptor class for the recycle view. It need the list.
 */
public class AccountAdaptor extends RecyclerView.Adapter<AccountAdaptor.ItemViewHolder> {

    private List<AccountDetail> mAccountDetailList;

    public AccountAdaptor(List<AccountDetail> accountDetails) {
        this.mAccountDetailList = accountDetails;

    }

    @Override
    public ItemViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.account_list_row, parent, false);

        return new ItemViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(ItemViewHolder holder, int position) {
        AccountDetail account = mAccountDetailList.get(position);
        holder.account_name.setText(account.getAccountName());
        holder.account_iban.setText(account.getAccountIban());
        holder.account_balance.setText(account.getAccountBalance());
    }

    @Override
    public int getItemCount() {
        return mAccountDetailList.size();
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder {
        public TextView account_name, account_iban, account_balance;

        public ItemViewHolder(View view) {
            super(view);
            account_name = (TextView) view.findViewById(R.id.account_name);
            account_iban = (TextView) view.findViewById(R.id.account_iban);
            account_balance = (TextView) view.findViewById(R.id.account_balance);
        }
    }

    /**
     * This method is used to update the listview
     *
     * @param list New list need to show in the ListView
     */
    public void setData(List<AccountDetail> list) {
        mAccountDetailList = list;
    }
}
