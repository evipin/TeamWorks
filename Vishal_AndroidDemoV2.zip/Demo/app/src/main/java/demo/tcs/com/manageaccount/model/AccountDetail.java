package demo.tcs.com.manageaccount.model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by 917517 on 7/26/2017.
 */


public class AccountDetail {
    @SerializedName("accountBalanceInCents")
    private String accountBalance;

    private String accountId;
    @SerializedName("isVisible")
    private Boolean isAccVisible;

    private String accountName;

    private String accountNumber;

    private String accountType;
    @SerializedName("iban")
    private String accountIban;

    private String accountCurrency;

    private String alias;

    public AccountDetail(String accountBalance, String accountId, Boolean isAccVisible, String accountName, String accountNumber, String accountType, String accountIban, String accountCurrency, String alias) {
        this.accountBalance = accountBalance;
        this.accountId = accountId;
        this.isAccVisible = isAccVisible;
        this.accountName = accountName;
        this.accountNumber = accountNumber;
        this.accountType = accountType;
        this.accountIban = accountIban;
        this.accountCurrency = accountCurrency;
        this.alias = alias;
    }

    public String getAccountBalance() {
        return accountBalance;
    }


    public String getAccountId() {
        return accountId;
    }


    public Boolean getIsAccVisible() {
        return isAccVisible;
    }


    public String getAccountName() {
        return accountName;
    }


    public String getAccountNumber() {
        return accountNumber;
    }


    public String getAccountType() {
        return accountType;
    }


    public String getAccountIban() {
        return accountIban;
    }


    public String getAccountCurrency() {
        return accountCurrency;
    }


    public String getAlias() {
        return alias;
    }


}
